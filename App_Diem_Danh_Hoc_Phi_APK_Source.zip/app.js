// QUẢN LÝ ĐIỂM DANH & HỌC PHÍ - LOGIC HOÀN CHỈNH

const ATTENDANCE_STATES = ["", "OK", "BẬN", "ỐM", "TL", "#"];
const STORAGE_KEY = "attendance_app_data_v1";
const USER_KEY = "attendance_app_user";

// Lấy ngày hiện tại định dạng D.M (VD: 13.11)
function getTodayDM() {
    const now = new Date();
    const d = now.getDate();
    const m = now.getMonth() + 1;
    return `${d}.${m}`;
}

// Dữ liệu mẫu khởi tạo ban đầu
function getInitialData() {
    const today = getTodayDM();
    return {
        currentClassId: "class_3d",
        classes: [
            {
                id: "class_3d",
                name: "LỚP TIẾNG ANH 3D",
                dates: ["7.11", "8.11", today],
                students: [
                    {
                        id: "st_1",
                        ho: "VŨ THỊ QUỲNH",
                        ten: "ANH",
                        donGia: 80000,
                        info: "Bình Giang, Hải Dương",
                        ddcn: "030117001234",
                        sdt: "0912345678",
                        speaking1: 10,
                        speaking2: 9.5,
                        sp1Rewarded: true,
                        sp2Rewarded: true,
                        tichLuy: 15000,
                        attendance: { "7.11": "OK", "8.11": "OK" }
                    },
                    {
                        id: "st_2",
                        ho: "VŨ KHÔI",
                        ten: "NGUYÊN",
                        donGia: 80000,
                        info: "Tân Việt, Bình Giang",
                        ddcn: "030115005678",
                        sdt: "0987654321",
                        speaking1: 9.5,
                        speaking2: "",
                        sp1Rewarded: true,
                        sp2Rewarded: false,
                        tichLuy: 5000,
                        attendance: { "7.11": "OK", "8.11": "BẬN" }
                    },
                    {
                        id: "st_3",
                        ho: "VŨ THỊ QUỲNH",
                        ten: "CHI",
                        donGia: 80000,
                        info: "Thôn 2, Tân Việt",
                        ddcn: "030117009999",
                        sdt: "0909112233",
                        speaking1: "",
                        speaking2: "",
                        sp1Rewarded: false,
                        sp2Rewarded: false,
                        tichLuy: 0,
                        attendance: { "7.11": "ỐM", "8.11": "OK" }
                    }
                ]
            }
        ]
    };
}

let appData = loadData();

function loadData() {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
        try {
            return JSON.parse(raw);
        } catch (e) {
            console.error(e);
        }
    }
    const init = getInitialData();
    saveData(init);
    return init;
}

function saveData(data = appData) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function formatVND(amount) {
    return Number(amount || 0).toLocaleString("en-US");
}

function showToast(msg) {
    const toast = document.getElementById("toast");
    toast.textContent = msg;
    toast.className = "toast show";
    setTimeout(() => {
        toast.className = toast.className.replace("show", "");
    }, 2700);
}

// Tính số buổi OK và Tổng tiền học phí
function calcStudentTuition(student) {
    let okCount = 0;
    if (student.attendance) {
        Object.values(student.attendance).forEach(val => {
            if (val === "OK") okCount++;
        });
    }
    const total = okCount * (Number(student.donGia) || 0);
    return { okCount, total };
}

// Tính tiền thưởng Speaking: điểm == 10 (+10,000), 9 < điểm < 10 (+5,000)
function calcSpeakingBonus(score) {
    const num = parseFloat(score);
    if (isNaN(num)) return 0;
    if (num === 10) return 10000;
    if (num > 9 && num < 10) return 5000;
    return 0;
}

// Tự động kiểm tra & chèn ngày hiện tại D.M nếu chưa có
function ensureTodayDate(cls) {
    const today = getTodayDM();
    if (!cls.dates.includes(today)) {
        cls.dates.push(today);
        saveData();
    }
    return today;
}

function getCurrentClass() {
    return appData.classes.find(c => c.id === appData.currentClassId) || appData.classes[0];
}

// XỬ LÝ ĐĂNG NHẬP
function checkAuth() {
    const user = localStorage.getItem(USER_KEY);
    if (user) {
        document.getElementById("login-screen").classList.remove("active");
        document.getElementById("main-screen").classList.add("active");
        renderApp();
    } else {
        document.getElementById("login-screen").classList.add("active");
        document.getElementById("main-screen").classList.remove("active");
    }
}

document.getElementById("login-form").addEventListener("submit", function(e) {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    if (email) {
        localStorage.setItem(USER_KEY, email);
        showToast(`Xin chào ${email}! Đã đồng bộ dữ liệu.`);
        checkAuth();
    }
});

document.getElementById("google-signin-btn").addEventListener("click", function() {
    localStorage.setItem(USER_KEY, "teacher.john@gmail.com");
    showToast("Đăng nhập Google thành công! Đã kết nối Google Drive.");
    checkAuth();
});

document.getElementById("logout-btn").addEventListener("click", function() {
    localStorage.removeItem(USER_KEY);
    checkAuth();
});

// RENDER BẢNG ĐIỂM DANH
function renderApp() {
    const cls = getCurrentClass();
    const today = ensureTodayDate(cls);

    // Render dropdown lớp học
    const select = document.getElementById("class-select");
    select.innerHTML = "";
    appData.classes.forEach(c => {
        const opt = document.createElement("option");
        opt.value = c.id;
        opt.textContent = c.name;
        if (c.id === cls.id) opt.selected = true;
        select.appendChild(opt);
    });

    // Render Header ngày tháng
    const headerRow = document.getElementById("header-row");
    // Xóa các cột ngày cũ
    headerRow.querySelectorAll(".header-date").forEach(el => el.remove());

    cls.dates.forEach(dateStr => {
        const th = document.createElement("th");
        th.className = "header-date" + (dateStr === today ? " today-col" : "");
        th.textContent = dateStr;
        headerRow.appendChild(th);
    });

    // Render danh sách học sinh
    const tbody = document.getElementById("student-tbody");
    tbody.innerHTML = "";

    cls.students.forEach((student, index) => {
        const tr = document.createElement("tr");
        const { total } = calcStudentTuition(student);

        // 1. STT
        const tdStt = document.createElement("td");
        tdStt.className = "sticky-col col-stt";
        tdStt.textContent = index + 1;
        tr.appendChild(tdStt);

        // 2. HỌ & ĐỆM
        const tdHo = document.createElement("td");
        tdHo.className = "sticky-col col-ho";
        tdHo.textContent = (student.ho || "").toUpperCase();
        attachNameGestures(tdHo, student, today);
        tr.appendChild(tdHo);

        // 3. TÊN
        const tdTen = document.createElement("td");
        tdTen.className = "sticky-col col-ten";
        tdTen.textContent = (student.ten || "").toUpperCase();
        attachNameGestures(tdTen, student, today);
        tr.appendChild(tdTen);

        // 4. TỔNG (Học phí)
        const tdTong = document.createElement("td");
        tdTong.className = "col-tong";
        tdTong.textContent = formatVND(total);
        tr.appendChild(tdTong);

        // 5. SPEAKING 1
        const tdSp1 = document.createElement("td");
        tdSp1.className = "col-sp";
        tdSp1.textContent = student.speaking1 !== "" && student.speaking1 !== undefined ? student.speaking1 : "";
        tdSp1.addEventListener("click", () => editSpeakingScore(student, 1));
        tr.appendChild(tdSp1);

        // 6. SPEAKING 2
        const tdSp2 = document.createElement("td");
        tdSp2.className = "col-sp";
        tdSp2.textContent = student.speaking2 !== "" && student.speaking2 !== undefined ? student.speaking2 : "";
        tdSp2.addEventListener("click", () => editSpeakingScore(student, 2));
        tr.appendChild(tdSp2);

        // 7. TÍCH LŨY (Chạm 3 lần liên tiếp để xóa điểm Speaking & Tích lũy)
        const tdTl = document.createElement("td");
        tdTl.className = "col-tl";
        tdTl.textContent = formatVND(student.tichLuy || 0);
        attachTripleTapReset(tdTl, student);
        tr.appendChild(tdTl);

        // 8. CÁC CỘT NGÀY ĐIỂM DANH
        cls.dates.forEach(dateStr => {
            const tdDate = document.createElement("td");
            const status = (student.attendance && student.attendance[dateStr]) || "";
            tdDate.className = "att-cell " + getAttendanceClass(status);
            tdDate.textContent = status;
            tdDate.addEventListener("click", () => {
                cycleAttendanceForDate(student, dateStr);
            });
            tr.appendChild(tdDate);
        });

        tbody.appendChild(tr);
    });

    // Tự động cuộn ngang tới cột ngày hiện tại
    setTimeout(() => {
        const container = document.getElementById("table-container");
        container.scrollLeft = container.scrollWidth;
    }, 50);
}

function getAttendanceClass(status) {
    if (status === "OK") return "att-ok";
    if (status === "BẬN") return "att-ban";
    if (["ỐM", "TL", "#"].includes(status)) return "att-special";
    return "";
}

// Vòng lặp trạng thái điểm danh: [Trống] -> OK -> BẬN -> ỐM -> TL -> # -> OK
function cycleAttendanceForDate(student, dateStr) {
    if (!student.attendance) student.attendance = {};
    const current = student.attendance[dateStr] || "";
    let nextIdx = ATTENDANCE_STATES.indexOf(current) + 1;
    if (nextIdx >= ATTENDANCE_STATES.length) {
        nextIdx = 1; // Quay lại OK
    }
    student.attendance[dateStr] = ATTENDANCE_STATES[nextIdx];
    saveData();
    renderApp();
}

// Gắn sự kiện: Chạm nhanh để điểm danh ngày hôm nay / Nhấn giữ 0.5s để mở modal chi tiết
function attachNameGestures(element, student, todayDate) {
    let pressTimer = null;
    let isLongPress = false;

    const startPress = (e) => {
        isLongPress = false;
        pressTimer = setTimeout(() => {
            isLongPress = true;
            openStudentDetailModal(student);
        }, 500); // 0.5 giây
    };

    const cancelPress = () => {
        if (pressTimer) {
            clearTimeout(pressTimer);
            pressTimer = null;
        }
    };

    element.addEventListener("mousedown", startPress);
    element.addEventListener("touchstart", startPress, { passive: true });

    element.addEventListener("mouseup", cancelPress);
    element.addEventListener("mouseleave", cancelPress);
    element.addEventListener("touchend", cancelPress);
    element.addEventListener("touchmove", cancelPress);

    element.addEventListener("click", (e) => {
        if (isLongPress) {
            e.preventDefault();
            return;
        }
        cycleAttendanceForDate(student, todayDate);
    });
}

// Nhập điểm SPEAKING 1 hoặc SPEAKING 2 & tự động cộng dồn TÍCH LŨY
function editSpeakingScore(student, slot) {
    const key = slot === 1 ? "speaking1" : "speaking2";
    const rewardFlag = slot === 1 ? "sp1Rewarded" : "sp2Rewarded";
    const currentVal = student[key] !== undefined ? student[key] : "";

    const input = prompt(`Nhập điểm SPEAKING ${slot} cho em ${student.ho} ${student.ten} (0 - 10):`, currentVal);
    if (input === null) return;

    const trimmed = input.trim();
    // Trừ lại điểm cũ nếu trước đó đã cộng thưởng cho ô này
    if (student[rewardFlag]) {
        const oldBonus = calcSpeakingBonus(student[key]);
        student.tichLuy = Math.max(0, (student.tichLuy || 0) - oldBonus);
        student[rewardFlag] = false;
    }

    if (trimmed === "") {
        student[key] = "";
    } else {
        const num = parseFloat(trimmed);
        if (isNaN(num) || num < 0 || num > 10) {
            alert("Vui lòng nhập điểm hợp lệ từ 0 đến 10!");
            return;
        }
        student[key] = num;
        const bonus = calcSpeakingBonus(num);
        if (bonus > 0) {
            student.tichLuy = (student.tichLuy || 0) + bonus;
            student[rewardFlag] = true;
            showToast(`+${formatVND(bonus)} VNĐ vào TÍCH LŨY cho em ${student.ten}!`);
        }
    }

    saveData();
    renderApp();
}

// Chạm 3 lần liên tiếp vào ô TÍCH LŨY để xóa điểm Speaking 1, Speaking 2 và tiền Tích lũy
function attachTripleTapReset(element, student) {
    let tapCount = 0;
    let tapTimer = null;

    element.addEventListener("click", () => {
        tapCount++;
        if (tapTimer) clearTimeout(tapTimer);

        if (tapCount === 3) {
            tapCount = 0;
            student.speaking1 = "";
            student.speaking2 = "";
            student.sp1Rewarded = false;
            student.sp2Rewarded = false;
            student.tichLuy = 0;
            saveData();
            renderApp();
            showToast(`Đã xóa điểm Speaking & TÍCH LŨY của ${student.ho} ${student.ten}!`);
        } else {
            tapTimer = setTimeout(() => {
                tapCount = 0;
            }, 600);
        }
    });
}

// MODAL CHI TIẾT HỌC SINH (NHẤN GIỮ 0.5S)
function openStudentDetailModal(student) {
    const cls = getCurrentClass();
    const { okCount, total } = calcStudentTuition(student);

    document.getElementById("edit-student-id").value = student.id;
    document.getElementById("modal-fullname-display").textContent = `${student.ho} ${student.ten}`.toUpperCase();
    document.getElementById("modal-class-display").textContent = cls.name;
    document.getElementById("modal-avatar").textContent = (student.ten || "HS").substring(0, 2).toUpperCase();

    document.getElementById("edit-ho").value = (student.ho || "").toUpperCase();
    document.getElementById("edit-ten").value = (student.ten || "").toUpperCase();
    document.getElementById("edit-dongia").value = student.donGia || 0;
    document.getElementById("edit-buoi").value = okCount;
    document.getElementById("edit-hocphi").value = formatVND(total) + " VNĐ";
    document.getElementById("edit-tichluy").value = student.tichLuy || 0;
    document.getElementById("edit-info").value = student.info || "";
    document.getElementById("edit-ddcn").value = student.ddcn || "";
    document.getElementById("edit-sdt").value = student.sdt || "";

    document.getElementById("student-modal").classList.add("active");
}

document.getElementById("close-student-modal").addEventListener("click", () => {
    document.getElementById("student-modal").classList.remove("active");
});

document.getElementById("student-detail-form").addEventListener("submit", function(e) {
    e.preventDefault();
    const cls = getCurrentClass();
    const stId = document.getElementById("edit-student-id").value;
    const student = cls.students.find(s => s.id === stId);
    if (!student) return;

    student.ho = document.getElementById("edit-ho").value.trim().toUpperCase();
    student.ten = document.getElementById("edit-ten").value.trim().toUpperCase();
    student.donGia = Number(document.getElementById("edit-dongia").value) || 0;
    student.tichLuy = Number(document.getElementById("edit-tichluy").value) || 0;
    student.info = document.getElementById("edit-info").value.trim();
    student.ddcn = document.getElementById("edit-ddcn").value.trim();
    student.sdt = document.getElementById("edit-sdt").value.trim();

    saveData();
    document.getElementById("student-modal").classList.remove("active");
    renderApp();
    showToast("Đã cập nhật thông tin học sinh!");
});

document.getElementById("delete-student-btn").addEventListener("click", function() {
    const cls = getCurrentClass();
    const stId = document.getElementById("edit-student-id").value;
    if (confirm("Bạn có chắc chắn muốn xóa học sinh này khỏi lớp?")) {
        cls.students = cls.students.filter(s => s.id !== stId);
        saveData();
        document.getElementById("student-modal").classList.remove("active");
        renderApp();
        showToast("Đã xóa học sinh.");
    }
});

// THÊM HỌC SINH MỚI
document.getElementById("add-student-btn").addEventListener("click", () => {
    document.getElementById("add-student-form").reset();
    document.getElementById("add-student-modal").classList.add("active");
});

document.getElementById("close-add-modal").addEventListener("click", () => {
    document.getElementById("add-student-modal").classList.remove("active");
});

document.getElementById("add-student-form").addEventListener("submit", function(e) {
    e.preventDefault();
    const cls = getCurrentClass();
    const newStudent = {
        id: "st_" + Date.now(),
        ho: document.getElementById("new-ho").value.trim().toUpperCase(),
        ten: document.getElementById("new-ten").value.trim().toUpperCase(),
        donGia: Number(document.getElementById("new-dongia").value) || 80000,
        info: document.getElementById("new-info").value.trim(),
        ddcn: document.getElementById("new-ddcn").value.trim(),
        sdt: document.getElementById("new-sdt").value.trim(),
        speaking1: "",
        speaking2: "",
        sp1Rewarded: false,
        sp2Rewarded: false,
        tichLuy: 0,
        attendance: {}
    };
    cls.students.push(newStudent);
    saveData();
    document.getElementById("add-student-modal").classList.remove("active");
    renderApp();
    showToast(`Đã thêm học sinh ${newStudent.ho} ${newStudent.ten}!`);
});

// CHỌN LỚP & THÊM LỚP MỚI
document.getElementById("class-select").addEventListener("change", function(e) {
    appData.currentClassId = e.target.value;
    saveData();
    renderApp();
});

document.getElementById("add-class-btn").addEventListener("click", function() {
    const className = prompt("Nhập tên lớp mới (VD: LỚP TIẾNG ANH 4A):");
    if (className && className.trim()) {
        const newCls = {
            id: "class_" + Date.now(),
            name: className.trim().toUpperCase(),
            dates: [getTodayDM()],
            students: []
        };
        appData.classes.push(newCls);
        appData.currentClassId = newCls.id;
        saveData();
        renderApp();
        showToast(`Đã tạo ${newCls.name}!`);
    }
});

// CHỐT SỔ THÁNG MỚI (Giữ nguyên TÍCH LŨY cộng dồn, làm mới bảng điểm danh & cột Speaking tháng mới)
document.getElementById("new-month-btn").addEventListener("click", function() {
    if (confirm("Chốt sổ sang tháng mới? Tiền TÍCH LŨY của học sinh sẽ được giữ nguyên để cộng dồn sang tháng mới, các cột điểm danh cũ sẽ được làm mới.")) {
        const cls = getCurrentClass();
        cls.dates = [getTodayDM()];
        cls.students.forEach(st => {
            st.attendance = {};
            st.speaking1 = "";
            st.speaking2 = "";
            st.sp1Rewarded = false;
            st.sp2Rewarded = false;
        });
        saveData();
        renderApp();
        showToast("Đã chuyển sang tháng mới & bảo lưu tiền TÍCH LŨY!");
    }
});

// SAO LƯU & ĐỒNG BỘ FILE JSON (GOOGLE DRIVE BACKUP)
document.getElementById("sync-btn").addEventListener("click", function() {
    saveData();
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(appData, null, 2));
    const dlAnchor = document.createElement("a");
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `DiemDanh_Backup_${getTodayDM().replace(".", "_")}.json`);
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();
    showToast("Đã lưu dữ liệu & tải file sao lưu lên máy/Drive!");
});

// Khởi chạy
checkAuth();
